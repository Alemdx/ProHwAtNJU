import com.alibaba.fastjson.JSONObject;
import dm.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;
import sink.MySink;

import java.util.Properties;


public class MyFlinkSinkClickhouse {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // source
        String topic = "transaction";

        Properties props = new Properties();
        // 设置连接kafka集群的参数
        props.setProperty("bootstrap.servers", "172.31.48.15:9092");
        props.setProperty("group.id", "consumer-group");
        props.setProperty("key.deserializer",
                "org.apache.kafka.common.serialization.StringDeserializer");
        props.setProperty("value.deserializer",
                "org.apache.kafka.common.serialization.StringDeserializer");

        // 定义Flink Kafka Consumer
        FlinkKafkaConsumer010<String> consumer = new FlinkKafkaConsumer010<>(topic, new SimpleStringSchema(), props);

        consumer.setStartFromGroupOffsets();
        consumer.setStartFromEarliest();    // 设置每次都从头消费

        // 添加source数据流
        DataStreamSource<String> source = env.addSource(consumer);
        System.err.println("数据流：" + source);


        SingleOutputStreamOperator<Object> dataStream = source.map((MapFunction<String, Object>) value -> {
            JSONObject jsonObject = JSONObject.parseObject(value);
            String eventType = jsonObject.getString("eventType");
            if (eventType == null) {
                return null;
            }
            switch (eventType) {
                case "sa":
                    return jsonObject.getObject("eventBody", dm_v_tr_sa_mx.class);
//                case "shop":
//                    return jsonObject.getObject("eventBody", dm_hlw_shop_info.class);
                case "djk":
                    return jsonObject.getObject("eventBody", dm_v_as_djk_info.class);
                case "djkfq":
                    return jsonObject.getObject("eventBody", dm_v_as_djkfq_info.class);
//                case "as_etc":
//                    return jsonObject.getObject("eventBody", dm_v_as_etc_info.class);
//                case "grwy":
//                    return jsonObject.getObject("eventBody", dm_v_as_grwy_info.class);
                case "sbdz":
                    return jsonObject.getObject("eventBody", dm_v_as_sbdz_info.class);
//                case "sbyb":
//                    return jsonObject.getObject("eventBody", dm_v_as_sbyb_info.class);
                case "sdm":
                    return jsonObject.getObject("eventBody", dm_v_as_sdm_info.class);
                case "sjhmzf":
                    return jsonObject.getObject("eventBody", dm_v_as_sjhmzf_info.class);
//                case "sjyh":
//                    return jsonObject.getObject("eventBody", dm_v_as_sjyh_info.class);
                case "wxyh":
                    return jsonObject.getObject("eventBody", dm_v_as_wxyh_info.class);
                case "ybdzpz":
                    return jsonObject.getObject("eventBody", dm_v_as_ybdzpz_info.class);
                case "ydzf":
                    return jsonObject.getObject("eventBody", dm_v_as_ydzf_info.class);
                case "contract":
                    return jsonObject.getObject("eventBody", dm_v_tr_contract_mx.class);
                case "dsf":
                    return jsonObject.getObject("eventBody", dm_v_tr_dsf_mx.class);
                case "duebill":
                    return jsonObject.getObject("eventBody", dm_v_tr_duebill_mx.class);
                case "etc":
                    return jsonObject.getObject("eventBody", dm_v_tr_etc_mx.class);
                case "grwy":
                    return jsonObject.getObject("eventBody", dm_v_tr_grwy_mx.class);
                case "gzdf":
                    return jsonObject.getObject("eventBody", dm_v_tr_gzdf_mx.class);
                case "huanb":
                    return jsonObject.getObject("eventBody", dm_v_tr_huanb_mx.class);
                case "huanx":
                    return jsonObject.getObject("eventBody", dm_v_tr_huanx_mx.class);
                case "sbyb":
                    return jsonObject.getObject("eventBody", dm_v_tr_sbyb_mx.class);
                case "sdrq":
                    return jsonObject.getObject("eventBody", dm_v_tr_sdrq_mx.class);
                case "sjyh":
                    return jsonObject.getObject("eventBody", dm_v_tr_sjyh_mx.class);
                case "acct":
                    return jsonObject.getObject("eventBody", pri_cust_asset_acct_info.class);
                case "asset":
                    return jsonObject.getObject("eventBody", pri_cust_asset_info.class);
                case "base":
                    return jsonObject.getObject("eventBody", pri_cust_base_info.class);
                case "contact":
                    return jsonObject.getObject("eventBody", pri_cust_contact_info.class);
                case "liab_acct":
                    return jsonObject.getObject("eventBody", pri_cust_liab_acct_info.class);
                case "liab":
                    return jsonObject.getObject("eventBody", pri_cust_liab_info.class);
                case "shop":
                    return jsonObject.getObject("eventBody", v_tr_shop_mx.class);
                case "credit":
                    return jsonObject.getObject("eventBody", pri_credit_info.class);
                case "star":
                    return jsonObject.getObject("eventBody", pri_star_info.class);
                default:
                    System.err.println("无法匹配： " + eventType);
                    return null;
            }
        });

//        System.out.println("dataStream");
//        dataStream.print();

        MySink<Object> sink = new MySink<>();
        dataStream.addSink(sink);

        env.execute();
    }
}
