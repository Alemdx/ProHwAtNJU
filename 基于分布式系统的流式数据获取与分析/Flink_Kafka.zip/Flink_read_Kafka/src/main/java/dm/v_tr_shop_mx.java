package dm;

import lombok.Data;

@Data
public class v_tr_shop_mx {
    String tran_channel;
    String order_code;
    String shop_code;
    String shop_name;
    String hlw_tran_type;
    String tran_date;
    String tran_time;
    Double tran_amt;
    String current_status;
    Double score_num;
    String pay_channel;
    String uid;
    String legal_name;
    String etl_dt;
}