package dm;

import lombok.Data;

@Data
public class dm_v_tr_huanb_mx {
    String tran_flag;
    String uid;
    String cust_name;
    String acct_no;
    String tran_date;
    String tran_time;
    Double tran_amt;
    Double bal;
    String tran_code;
    String dr_cr_code;
    int pay_term;
    String tran_teller_no;
    Double pprd_rfn_amt;
    Double pprd_amotz_intr;
    String tran_log_no;
    String tran_type;
    String dscrp_code;
    String remark;
    String etl_dt;
}

