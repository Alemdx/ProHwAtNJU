package dm;

import lombok.Data;

@Data
public class dm_hlw_shop_info {
    String shop_code;
    String shop_name;
    String shop_reg_date;
    String shop_add;
    String is_dafeng;
    String shop_type;
    String user_code;
    String band_card_no;
    String band_card_date;
    String is_inter_card;
    String is_cloud_flash;
    Double card_bal;
    Double card_avg_year;
    Double card_avg_mth;
    Double all_dep_bal;
    String legal_name;
    String uid;
    String legal_mob_phone;
    String shop_sts;
    String del_flag;
    String engage_type;
    String recom_no;
    String recom_name;
    String recom_org;
    String recom_org_name;
    String recom_phone;
    int tran_cnt_year;
    Double tran_amt_year;
    int tran_cnt_mth;
    Double tran_amt_mth;
    String class_year;
    String class_mth;
    Double online_loan_bal;
    Double all_loan_bal;
    String etl_dt;

}






















