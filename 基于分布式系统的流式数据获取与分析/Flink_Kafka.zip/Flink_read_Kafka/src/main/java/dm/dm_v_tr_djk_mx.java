package dm;

import lombok.Data;

@Data
public class dm_v_tr_djk_mx {
    String uid;
    String card_no;
    String tran_type;
    String tran_type_desc;
    Double tran_amt;
    String tran_amt_sign;
    String mer_type;
    String mer_code;
    String rev_ind;
    String tran_desc;
    String tran_date;
    String val_date;
    String pur_date;
    String tran_time;
    String acct_no;
    String etl_dt;
}