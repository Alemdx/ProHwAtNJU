package dm;

import lombok.Data;

@Data
public class dm_v_as_etc_info {
    String belong_org;
    String etc_acct;
    String etc_acct_type;
    String band_acct;
    String band_acct_owner;
    String cust_name;
    String uid;
    String sign_date;
    String mob_phone;
    String car_no;
    String car_model;
    String car_color;
    String buy_time;
    String car_sts;
    String seats;
    String car_type;
    String vehicle_type;
    String owner_name;
    String owner_cert_no;
    String owner_phone;
    String book_channel;
    String book_org;
    String book_emp;
    String book_emp_name;
    String cust_sts;
    String is_clsd_his;
    String etl_dt;
}