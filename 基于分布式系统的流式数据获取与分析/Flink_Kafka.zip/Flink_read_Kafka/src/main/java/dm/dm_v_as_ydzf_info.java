package dm;

import lombok.Data;

@Data
public class dm_v_as_ydzf_info {
    String type;
    String type_name;
    String belong_org;
    String acct_no;
    String is_secu_card;
    String cust_name;
    String uid;
    String sign_date;
    String sign_time;
    String sign_status;
    String cancel_date;
    String cancel_time;
    String recom_channel;
    String recom_org;
    String recom_no;
    String mob_phone;
    String etl_dt;
}