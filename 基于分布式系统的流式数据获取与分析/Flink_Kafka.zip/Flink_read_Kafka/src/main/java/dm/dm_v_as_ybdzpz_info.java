package dm;

import lombok.Data;

@Data
public class dm_v_as_ybdzpz_info {
    String uid;
    String ebank_cust_no;
    String sign_date;
    String recom_no;
    String recom_name;
    String belong_org;
    String bel_org_name;
    String etl_dt;
}