package dm;

import lombok.Data;

@Data
public class dm_v_tr_gzdf_mx {
    String belong_org;
    String ent_acct;
    String ent_name;
    String eng_cert_no;
    String acct_no;
    String cust_name;
    String uid;
    String tran_date;
    Double tran_amt;
    String tran_log_no;
    String is_secu_card;
    String trna_channel;
    String batch_no;
    String etl_dt;
}