package dm;

import lombok.Data;

@Data
public class dm_v_as_grwy_info {
    String belong_org;
    String ebank_cust_no;
    String cust_name;
    String uid;
    String acct_no;
    String open_date;
    String open_teller_no;
    String mob_phone;
    String status;
    String last_tran_dt;
    String etl_dt;
}