package dm;

import lombok.Data;

@Data
public class pri_star_info {
    String uid;
    String star_level;
}