package dm;

import lombok.Data;

@Data
public class dm_v_tr_sjyh_mx {
    String uid;
    String mch_channel;
    String login_type;
    String ebank_cust_no;
    String tran_date;
    String tran_time;
    String tran_code;
    String tran_sts;
    String return_code;
    String return_msg;
    String sys_type;
    String payer_acct_no;
    String payer_acct_name;
    String payee_acct_no;
    String payee_acct_name;
    Double tran_amt;
    String etl_dt;
}
