package dm;

import lombok.Data;

@Data
public class dm_v_tr_sbyb_mx {
    String uid;
    String cust_name;
    String tran_date;
    String tran_sts;
    String tran_org;
    String tran_teller_no;
    Double tran_amt_fen;
    String tran_type;
    String return_msg;
    String etl_dt;
}
