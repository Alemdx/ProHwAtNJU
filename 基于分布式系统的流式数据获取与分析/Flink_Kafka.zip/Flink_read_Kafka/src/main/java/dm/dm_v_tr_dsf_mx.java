package dm;

import lombok.Data;

@Data
public class dm_v_tr_dsf_mx {
    String tran_date;
    String tran_log_no;
    String tran_code;
    String channel_flg;
    String tran_org;
    String tran_teller_no;
    String dc_flag;
    Double tran_amt;
    String send_bank;
    String payer_open_bank;
    String payer_acct_no;
    String payer_name;
    String payee_open_bank;
    String payee_acct_no;
    String payee_name;
    String tran_sts;
    String busi_type;
    String busi_sub_type;
    String etl_dt;
    String uid;
}
