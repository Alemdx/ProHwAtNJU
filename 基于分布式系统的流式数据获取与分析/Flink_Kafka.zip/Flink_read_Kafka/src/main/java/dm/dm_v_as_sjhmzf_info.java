package dm;

import lombok.Data;

@Data
public class dm_v_as_sjhmzf_info {
    String belong_org;
    String cust_name;
    String uid;
    String mob_phone;
    String card_no;
    String recom_no;
    String recom_name;
    String sign_date;
    String etl_dt;
}
