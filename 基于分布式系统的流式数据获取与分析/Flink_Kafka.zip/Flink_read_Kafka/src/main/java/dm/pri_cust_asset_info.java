package dm;

import lombok.Data;

@Data
public class pri_cust_asset_info {
    String cust_no;
    String cust_name;
    String uid;
    String belong_org;
    String exam_org;
    Double all_bal;
    Double avg_mth;
    Double avg_qur;
    Double avg_year;
    Double sa_bal;
    Double td_bal;
    Double fin_bal;
    Double sa_crd_bal;
    Double td_crd_bal;
    Double sa_td_bal;
    Double ntc_bal;
    Double td_3m_bal;
    Double td_6m_bal;
    Double td_1y_bal;
    Double td_2y_bal;
    Double td_3y_bal;
    Double td_5y_bal;
    Double oth_td_bal;
    Double cd_bal;
    String etl_dt;
}

