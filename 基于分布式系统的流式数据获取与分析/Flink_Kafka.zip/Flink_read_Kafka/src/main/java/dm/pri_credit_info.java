package dm;

import lombok.Data;

@Data
public class pri_credit_info {
    String uid;
    String credit_level;
}