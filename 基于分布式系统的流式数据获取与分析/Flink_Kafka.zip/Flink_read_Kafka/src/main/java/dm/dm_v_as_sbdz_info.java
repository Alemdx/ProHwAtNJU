package dm;

import lombok.Data;

@Data
public class dm_v_as_sbdz_info {
    String uid;
    String cust_name;
    String sign_date;
    String recom_no;
    String recom_name;
    String belong_org;
    String bel_org_name;
    String etl_dt;
}