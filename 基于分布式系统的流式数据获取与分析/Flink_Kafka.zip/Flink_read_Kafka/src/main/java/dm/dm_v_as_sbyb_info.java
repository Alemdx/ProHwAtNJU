package dm;

import lombok.Data;

@Data
public class dm_v_as_sbyb_info {
    String uid;
    String cust_name;
    String acct_no;
    String acct_name;
    String belong_org;
    String sign_date;
    String etl_dt;
}