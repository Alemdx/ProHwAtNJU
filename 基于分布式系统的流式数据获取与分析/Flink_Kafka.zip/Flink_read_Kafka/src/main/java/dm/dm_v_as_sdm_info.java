package dm;

import lombok.Data;

@Data
public class dm_v_as_sdm_info {
    String type;
    String exam_org;
    String household_no;
    String sign_date;
    String acct_no;
    String cust_name;
    String uid;
    String is_secu_card;
    String sign_teller_no;
    String recom_no;
    String belong_org;
    String book_channel;
    String sign_channel;
    String etl_dt;
}