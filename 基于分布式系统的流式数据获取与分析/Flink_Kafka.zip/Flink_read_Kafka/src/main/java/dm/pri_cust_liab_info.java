package dm;

import lombok.Data;

@Data
public class pri_cust_liab_info {
    String uid;
    Double all_bal;
    Double bad_bal;
    Double due_intr;
    Double norm_bal;
    Double delay_bal;
    String etl_dt;
}