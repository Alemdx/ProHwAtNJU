package dm;

import lombok.Data;

@Data
public class dm_v_as_djk_info {
    String acct_no;
    String card_no;
    String cust_name;
    String prod_code;
    String prod_name;
    String uid;
    String entp_name;
    String open_date;
    String card_sts;
    String card_sts_name;
    String card_sts_date;
    String is_withdrw;
    String is_transfer;
    String is_deposit;
    String is_purchse;
    Double cred_limit;
    String mob_phone;
    Double deposit;
    Double over_draft;
    Double dlay_amt;
    String five_class;
    String bankacct;
    String bankacct_date;
    Double bankacct_bal;
    String is_mob_bank;
    String mob_bank_date;
    String is_etc;
    String etc_date;
    String issue_mode;
    String issue_mode_name;
    Double bal;
    String active_date;
    String clsd_date;
    int dlay_mths;
    String mgr_no;
    String mgr_name;
    String recom_name;
    String mge_org;
    String mge_org_name;
    String etl_dt;
}