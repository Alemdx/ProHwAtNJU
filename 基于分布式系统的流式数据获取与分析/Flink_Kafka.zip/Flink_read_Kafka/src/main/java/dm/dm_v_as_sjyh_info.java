package dm;

import lombok.Data;

@Data
public class dm_v_as_sjyh_info {
    String belong_org;
    String ebank_cust_no;
    String cust_name;
    String uid;
    String acct_no;
    String open_date;
    String reg_flag;
    String reg_flag_name;
    String open_teller_no;
    String recom_no;
    String recom_org;
    String mob_phone;
    String user_seq;
    String status;
    String is_djk;
    String is_sbk;
    Double interbank_lmtamt;
    Double innerbank_lmtamt;
    Double tran_lmtamt;
    String last_tran_dt;
    String etl_dt;
}