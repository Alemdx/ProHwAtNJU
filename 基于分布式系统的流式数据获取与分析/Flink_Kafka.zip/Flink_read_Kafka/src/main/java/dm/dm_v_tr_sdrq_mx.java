package dm;

import lombok.Data;

@Data
public class dm_v_tr_sdrq_mx {
    String hosehld_no;
    String acct_no;
    String cust_name;
    String tran_type;
    String tran_date;
    Double tran_amt_fen;
    String channel_flg;
    String tran_org;
    String tran_teller_no;
    String tran_log_no;
    String batch_no;
    String tran_sts;
    String return_msg;
    String etl_dt;
    String uid;
}

