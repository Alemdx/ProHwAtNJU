package dm;

import lombok.Data;

@Data
public class dm_v_as_wxyh_info {
    String wechat_no;
    String acct_no;
    String acct_type;
    String uid;
    String band_sts;
    String band_date;
    String cust_no;
    String cust_name;
    String belong_org;
    String mob_phone;
    String email;
    String address;
    String notice_flag;
    String recom_no;
    String etl_dt;
}