package dm;

import lombok.Data;

@Data
public class dm_v_tr_sa_mx {
    String uid;
    String card_no;
    String cust_name;
    String acct_no;
    int det_n;
    String curr_type;
    String tran_teller_no;
    Double cr_amt;
    Double bal;
    Double tran_amt;
    String tran_card_no;
    String tran_type;
    String tran_log_no;
    Double dr_amt;
    String open_org;
    String dscrp_code;
    String remark;
    String tran_time;
    String tran_date;
    String sys_date;
    String tran_code;
    String remark_1;
    String oppo_cust_name;
    String agt_cert_type;
    String agt_cert_no;
    String agt_cust_name;
    String channel_flag;
    String oppo_acct_no;
    String oppo_bank_no;
    String src_dt;
    String etl_dt;
}
