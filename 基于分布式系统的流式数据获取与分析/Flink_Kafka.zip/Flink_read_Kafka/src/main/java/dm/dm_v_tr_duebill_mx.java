package dm;

import lombok.Data;

@Data
public class dm_v_tr_duebill_mx {
    String uid;
    String acct_no;
    String receipt_no;
    String contract_no;
    String subject_no;
    String cust_no;
    String loan_cust_no;
    String cust_name;
    String buss_type;
    String curr_type;
    Double buss_amt;
    String putout_date;
    String matu_date;
    String actu_matu_date;
    Double buss_rate;
    Double actu_buss_rate;
    String intr_type;
    String intr_cyc;
    int pay_times;
    String pay_cyc;
    int extend_times;
    Double bal;
    Double norm_bal;
    Double dlay_amt;
    Double dull_amt;
    Double bad_debt_amt;
    Double owed_int_in;
    Double owed_int_out;
    Double fine_pr_int;
    Double fine_intr_int;
    int dlay_days;
    String pay_acct;
    String putout_acct;
    String pay_back_acct;
    int due_intr_days;
    String operate_org;
    String operator;
    String reg_org;
    String register;
    String occur_date;
    String loan_use;
    String pay_type;
    String pay_freq;
    String vouch_type;
    String mgr_no;
    String mge_org;
    String loan_channel;
    String ten_class;
    String src_dt;
    String etl_dt;
}
