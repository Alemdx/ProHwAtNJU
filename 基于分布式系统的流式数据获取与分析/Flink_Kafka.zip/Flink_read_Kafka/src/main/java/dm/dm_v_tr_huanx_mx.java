package dm;

import lombok.Data;

@Data
public class dm_v_tr_huanx_mx {
    String tran_flag;
    String uid;
    String cust_name;
    String acct_no;
    String tran_date;
    String tran_time;
    Double tran_amt;
    Double cac_intc_pr;
    String tran_code;
    String dr_cr_code;
    int pay_term;
    String tran_teller_no;
    String intc_strt_date;
    String intc_end_date;
    Double intr;
    String tran_log_no;
    String tran_type;
    String dscrp_code;
    String etl_dt;
}

