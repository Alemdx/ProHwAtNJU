package dm;

import lombok.Data;

@Data
public class dm_v_as_djkfq_info {
    String acct_no;
    String card_no;
    String cust_name;
    String uid;
    String mob_phone;
    String mge_org;
    String recom_no;
    String mp_number;
    String mp_type;
    String mp_status;
    String purch_date;
    String purch_mth;
    Double total_amt;
    int total_mths;
    Double mth_instl;
    int instl_cnt;
    Double rem_ppl;
    Double total_fee;
    Double rem_fee;
    Double rec_fee;
    String etl_dt;
}