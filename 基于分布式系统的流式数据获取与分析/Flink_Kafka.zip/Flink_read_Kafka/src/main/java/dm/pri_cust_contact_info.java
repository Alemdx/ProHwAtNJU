package dm;

import lombok.Data;

@Data
public class pri_cust_contact_info {
    String uid;
    String con_type;
    String contact;
    String sys_source;
    String create_date;
    String update_date;
    String etl_dt;
}

