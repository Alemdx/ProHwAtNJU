package dm;

import lombok.Data;

@Data
public class pri_cust_asset_acct_info {
    String cust_no;
    String cust_name;
    String uid;
    String acct_no;
    String card_no;
    String curr_type;
    String subject_no;
    String prod_type;
    String term;
    Double rate;
    String auto_dp_flg;
    String belong_org;
    String exam_org;
    String open_org;
    String open_date;
    String open_teller_no;
    String matu_date;
    String acct_char;
    String deps_type;
    String prod_code;
    String clsd_org;
    String clsd_date;
    String clsd_teller_no;
    String is_secu_card;
    String acct_sts;
    String frz_sts;
    String stp_sts;
    Double acct_bal;
    Double bal;
    Double avg_mth;
    Double avg_qur;
    Double avg_year;
    String etl_dt;
}