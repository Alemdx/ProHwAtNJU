package dm;

import lombok.Data;

@Data
public class dm_v_tr_etc_mx {
    String uid;
    String etc_acct;
    String card_no;
    String car_no;
    String cust_name;
    String tran_date;
    String tran_time;
    Double tran_amt_fen;
    Double real_amt;
    Double conces_amt;
    String tran_place;
    String mob_phone;
    String etl_dt;
}
