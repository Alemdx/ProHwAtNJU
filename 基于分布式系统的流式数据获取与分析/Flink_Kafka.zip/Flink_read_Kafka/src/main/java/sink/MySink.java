package sink;

import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import ru.yandex.clickhouse.ClickHouseConnection;
import ru.yandex.clickhouse.ClickHouseDataSource;
import ru.yandex.clickhouse.settings.ClickHouseProperties;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;

public class MySink<T> extends RichSinkFunction<T> {

    ClickHouseConnection conn = null;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
    }

    @Override
    public void close() throws Exception {
        super.close();
        if (conn != null) {
            conn.close();
        }

    }

    @Override
    public void invoke(T t, Context context) {
        if (t == null) return;

        Class<?> cls = t.getClass();

        String url = "jdbc:clickhouse://localhost:8123/dm";
        ClickHouseProperties properties = new ClickHouseProperties();
        properties.setUser("admin");
        properties.setPassword("x");
        properties.setSessionId("default-session-id");

        ClickHouseDataSource dataSource = new ClickHouseDataSource(url, properties);
//        Map<ClickHouseQueryParam, String> additionalDBParams = new HashMap<>();
//        additionalDBParams.put(ClickHouseQueryParam.SESSION_ID, "new-session-id");

        try {
            Field[] fields = cls.getDeclaredFields();
            String tableName = cls.getName();

            conn = dataSource.getConnection();
            StringBuilder sql = new StringBuilder("INSERT INTO " + tableName + " VALUES (?");
            for (int i = 1; i < fields.length; ++i) {
                sql.append(", ?");
            }
            sql.append(")");

//            System.out.println("插入语句：" + sql);

            PreparedStatement preparedStatement = conn.prepareStatement(sql.toString());

            for (int i = 0; i < fields.length; ++i) {
                Field field = fields[i];
                String fieldName = field.getName();
                fieldName = fieldName.replaceFirst(fieldName.substring(0, 1), fieldName.substring(0, 1).toUpperCase());
                Method method = cls.getMethod("get" + fieldName);

                Class<?> type = field.getType();
                Object fieldValue = method.invoke(t);

                if (type.equals(String.class)) {
                    preparedStatement.setString(i + 1, (String) fieldValue);
                } else if (type.equals(int.class)) {
                    preparedStatement.setInt(i + 1, (int) fieldValue);
                } else if (type.equals(Double.class)) {
                    preparedStatement.setDouble(i + 1, (Double) fieldValue);
                }

            }
            preparedStatement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
